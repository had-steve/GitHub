    return jsonify({"msg": "No linked bank account"}), 400

    # In a real app, you'd use Plaid's payment APIs or ACH provider here.
    # Below is an example using Plaid's payment initiation (UK/EU only).
    # For US transfers, you would need a provider like Stripe, Dwolla, or your bank's API.
    try:
        # Create recipient (simulate, hardcoded for demo)
        recipient_request = PaymentInitiationRecipientCreateRequest(
            name="Recipient",
            iban=recipient_iban,
            address={
                "street": ["Street"],
                "city": "City",
                "postal_code": "10000",
                "country": "GB"
            }
        )
        recipient_response = plaid_client.payment_initiation_recipient_create(recipient_request)
        recipient_id = recipient_response['recipient_id']

        # Create payment
        payment_request = PaymentInitiationPaymentCreateRequest(
            recipient_id=recipient_id,
            reference="Gold App Payment",
            amount=PaymentAmount(
                currency=PaymentAmountCurrency("GBP"),
                value=amount
            )
        )
        payment_response = plaid_client.payment_initiation_payment_create(payment_request)
        payment_id = payment_response['payment_id']

        return jsonify({"msg": "Payment initiated!", "payment_id": payment_id})
    except Exception as e:
        return jsonify({"msg": str(e)}), 500

if __name__ == "__main__":
    app.run(port=5000, debug=True)