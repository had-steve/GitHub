import kivy
from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
import requests

API_BASE = "http://10.0.2.2:5000"  # Android emulator localhost

class LoginScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = BoxLayout(orientation='vertical', spacing=10, padding=40)
        self.username = TextInput(hint_text='Username')
        self.password = TextInput(hint_text='Password', password=True)
        self.message = Label(text='')
        login_btn = Button(text='Login', background_color=(1, 0.84, 0, 1))
        login_btn.bind(on_press=self.login)
        layout.add_widget(Label(text='Gold App', font_size=32, color=(1, 0.84, 0, 1)))
        layout.add_widget(self.username)
        layout.add_widget(self.password)
        layout.add_widget(login_btn)
        layout.add_widget(self.message)
        self.add_widget(layout)

    def login(self, instance):
        resp = requests.post(f"{API_BASE}/login", json={
            "username": self.username.text,
            "password": self.password.text
        })
        if resp.status_code == 200:
            token = resp.json()["access_token"]
            self.manager.current = 'main'
            self.manager.get_screen('main').token = token
        else:
            self.message.text = "Invalid credentials"

class MainScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = BoxLayout(orientation='vertical', spacing=10, padding=40)
        layout.add_widget(Label(text='Send to Bank', font_size=24, color=(1, 0.84, 0, 1)))
        self.amount = TextInput(hint_text='Enter Amount', input_filter='float')
        self.iban = TextInput(hint_text='IBAN')
        send_btn = Button(text='Send', background_color=(1, 0.84, 0, 1))
        send_btn.bind(on_press=self.send_money)
        self.result = Label(text='')
        layout.add_widget(self.amount)
        layout.add_widget(self.iban)
        layout.add_widget(send_btn)
        layout.add_widget(self.result)
        self.add_widget(layout)
        self.token = ""

    def send_money(self, instance):
        headers = {"Authorization": f"Bearer {self.token}"}
        data = {
            "amount": self.amount.text,
            "iban": self.iban.text
        }
        resp = requests.post(f"{API_BASE}/send_money", json=data, headers=headers)
        if resp.status_code == 200:
            self.result.text = "Transaction successful!"
        else:
            self.result.text = "Failed: " + resp.json().get("msg", "")

class GoldApp(App):
    def build(self):
        sm = ScreenManager()
        sm.add_widget(LoginScreen(name='login'))
        sm.add_widget(MainScreen(name='main'))
        return sm

if __name__ == '__main__':
    GoldApp().run()